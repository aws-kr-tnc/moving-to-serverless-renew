export const SET_ACCESS_TOKEN = 'setAccessToken';
export const SET_REFRESH_TOKEN = 'setRereshToken';
export const SET_ALL_PHOTO_LIST = 'setAllPhotoList';
export const DELETE_ONE_PHOTO = 'deleteOnePhoto';
export const SET_IS_LOADING = 'isLoading';
