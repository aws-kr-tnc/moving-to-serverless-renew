const state = {
  photoList: [],
  isLoading: false,
};

export default state;
