<template>
  <v-content>
    <router-view/>
  </v-content>
</template>

<script>
export default {
  name: 'LayoutBody',
};
</script>

<style scoped>

</style>
