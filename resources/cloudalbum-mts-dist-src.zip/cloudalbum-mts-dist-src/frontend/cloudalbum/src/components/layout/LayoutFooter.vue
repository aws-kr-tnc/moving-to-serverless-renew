<template>
  <v-footer
    color="secondary"
    app
  >
    <span class="white--text">&copy; 2019 <v-icon>mdi-aws</v-icon> Amazon Web Services</span>
  </v-footer>
</template>

<script>
export default {
  name: 'LayoutFooter',
};
</script>

<style scoped>

</style>
