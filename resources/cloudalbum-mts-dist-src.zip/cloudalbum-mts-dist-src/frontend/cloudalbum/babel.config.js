module.exports = {
  presets: [
    '@vue/application',
  ],
};
