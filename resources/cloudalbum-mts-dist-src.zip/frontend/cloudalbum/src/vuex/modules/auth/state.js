const state = {
  accessToken: null,
  refreshToken: null,
  errorMessage: '',
};

export default state;
