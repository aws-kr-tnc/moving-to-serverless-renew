import signIn from '@/service/auth/SiginIn';
import signUp from '@/service/auth/SignUp';
import signOut from '@/service/auth/SignOut';

export default {
  signIn,
  signUp,
  signOut,
};
