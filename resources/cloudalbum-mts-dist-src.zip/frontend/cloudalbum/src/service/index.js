import Auth from '@/service/auth';
import Photo from '@/service/photo';

export default {
  Auth,
  Photo,
};
